
-- 创建数据库
CREATE DATABASE IF NOT EXISTS acwing_clone DEFAULT CHARSET utf8mb4 COLLATE utf8mb4_general_ci;
USE acwing_clone;

-- 用户表
CREATE TABLE user (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nickname VARCHAR(50),
    email VARCHAR(100),
    phone VARCHAR(20),
    avatar_url VARCHAR(255),
    role VARCHAR(20) DEFAULT 'USER',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 课程表
CREATE TABLE course (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) DEFAULT 0.00,
    image_url VARCHAR(255),
    is_member_only BOOLEAN DEFAULT TRUE,
    video_count INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'ACTIVE',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 视频表
CREATE TABLE video (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    course_id BIGINT NOT NULL,
    title VARCHAR(100) NOT NULL,
    video_url VARCHAR(255),
    duration INT,
    is_free BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (course_id) REFERENCES course(id) ON DELETE CASCADE
);

-- 订单表
CREATE TABLE `order` (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    total_price DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'PENDING',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user(id)
);

-- 订单明细表
CREATE TABLE order_item (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT NOT NULL,
    course_id BIGINT NOT NULL,
    course_title VARCHAR(100),
    price DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES `order`(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES course(id)
);

-- 下载资料表
CREATE TABLE download (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    course_id BIGINT NOT NULL,
    file_name VARCHAR(255),
    file_url VARCHAR(255),
    upload_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES course(id)
);

-- 会员状态记录表
CREATE TABLE membership (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    level VARCHAR(20) DEFAULT 'BASIC',
    start_date DATE,
    end_date DATE,
    FOREIGN KEY (user_id) REFERENCES user(id)
);
USE acwing_clone;

-- 插入用户数据
INSERT INTO user (username, password, nickname, email, role) VALUES
                                                                 ('alice', '$2a$10$7b3oV2L/8b7vA.gP9bNjI.0i6m2G7CrWRUpJHv6/Z13YOYleETo3G', 'Alice', 'alice@example.com', 'USER'),
                                                                 ('bob', '$2a$10$7b3oV2L/8b7vA.gP9bNjI.0i6m2G7CrWRUpJHv6/Z13YOYleETo3G', 'Bob', 'bob@example.com', 'USER');

-- 插入课程数据
INSERT INTO course (title, description, price, image_url, is_member_only, video_count, status) VALUES
                                                                                                   ('算法基础课', '适合初学者掌握算法基础', 199.00, '', FALSE, 20, 'ACTIVE'),
                                                                                                   ('Web开发实战', '掌握前后端开发技能', 249.00, '', FALSE, 30, 'ACTIVE'),
                                                                                                   ('考研408专项课', '专为考研408设计', 299.00, '', TRUE, 25, 'ACTIVE');

-- 插入视频数据
INSERT INTO video (course_id, title, video_url, duration, is_free) VALUES
                                                                       (1, '算法导论', 'https://video.example.com/1.mp4', 900, TRUE),
                                                                       (1, '排序算法', 'https://video.example.com/2.mp4', 1100, FALSE),
                                                                       (2, 'HTML基础', 'https://video.example.com/3.mp4', 800, TRUE),
                                                                       (3, '考研数学技巧', 'https://video.example.com/4.mp4', 1200, FALSE);

-- 插入订单和明细
INSERT INTO `order` (user_id, total_price, status) VALUES
                                                       (1, 199.00, 'PAID'),
                                                       (2, 548.00, 'PAID');

INSERT INTO order_item (order_id, course_id, course_title, price) VALUES
                                                                      (1, 1, '算法基础课', 199.00),
                                                                      (2, 2, 'Web开发实战', 249.00),
                                                                      (2, 3, '考研408专项课', 299.00);

-- 插入下载资料
INSERT INTO download (course_id, file_name, file_url) VALUES
                                                          (1, '算法笔记.pdf', 'https://files.example.com/algorithms.pdf'),
                                                          (2, 'Web项目源码.zip', 'https://files.example.com/webdev.zip');

-- 插入会员记录
INSERT INTO membership (user_id, level, start_date, end_date) VALUES
                                                                  (1, 'VIP', '2024-01-01', '2025-01-01'),
                                                                  (2, 'BASIC', '2024-02-01', '2024-08-01');