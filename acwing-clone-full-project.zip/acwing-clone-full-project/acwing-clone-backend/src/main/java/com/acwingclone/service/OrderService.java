package com.acwingclone.service;

import com.acwingclone.dto.OrderRequest;
import com.acwingclone.entity.Order;

import java.util.List;

public interface OrderService {
    void createOrder(Long userId, OrderRequest request);
    List<Order> getUserOrders(Long userId);
}
