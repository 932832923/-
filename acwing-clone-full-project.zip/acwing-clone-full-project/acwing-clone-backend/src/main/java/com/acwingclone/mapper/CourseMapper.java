package com.acwingclone.mapper;

import com.acwingclone.entity.Course;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CourseMapper {
    @Select("SELECT * FROM course WHERE status = 'ACTIVE'")
    List<Course> getAllActiveCourses();

    @Select("SELECT * FROM course WHERE id = #{id}")
    Course getCourseById(Long id);
}
