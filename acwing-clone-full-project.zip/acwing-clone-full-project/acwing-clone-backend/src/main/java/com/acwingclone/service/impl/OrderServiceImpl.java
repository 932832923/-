package com.acwingclone.service.impl;

import com.acwingclone.dto.OrderRequest;
import com.acwingclone.entity.Course;
import com.acwingclone.entity.Order;
import com.acwingclone.entity.OrderItem;
import com.acwingclone.mapper.CourseMapper;
import com.acwingclone.mapper.OrderItemMapper;
import com.acwingclone.mapper.OrderMapper;
import com.acwingclone.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private OrderItemMapper orderItemMapper;

    @Autowired
    private CourseMapper courseMapper;

    @Override
    public void createOrder(Long userId, OrderRequest request) {
        Order order = new Order();
        order.setUserId(userId);
        order.setTotalPrice(request.getTotalPrice());
        order.setStatus("PENDING");
        orderMapper.save(order);

        for (Long courseId : request.getCourseIdList()) {
            Course course = courseMapper.getCourseById(courseId);
            OrderItem item = new OrderItem();
            item.setOrderId(order.getId());
            item.setCourseId(course.getId());
            item.setCourseTitle(course.getTitle());
            item.setPrice(course.getPrice());
            orderItemMapper.save(item);
        }
    }

    @Override
    public List<Order> getUserOrders(Long userId) {
        return orderMapper.findOrdersByUserId(userId);
    }
}
