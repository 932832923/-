package com.acwingclone.service;

import com.acwingclone.entity.User;

public interface UserService {
    String login(String username, String password);
    void register(User user);
    User getUserByUsername(String username);
}
