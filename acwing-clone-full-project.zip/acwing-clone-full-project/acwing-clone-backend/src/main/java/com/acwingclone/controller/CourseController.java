package com.acwingclone.controller;

import com.acwingclone.entity.Course;
import com.acwingclone.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/course")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @GetMapping("/list")
    public List<Course> getAllCourses() {
        return courseService.getAllCourses();
    }

    @GetMapping("/{id}")
    public Course getCourseDetail(@PathVariable Long id) {
        return courseService.getCourseDetail(id);
    }
}
