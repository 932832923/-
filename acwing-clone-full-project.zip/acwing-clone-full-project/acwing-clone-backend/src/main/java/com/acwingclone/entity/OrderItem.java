package com.acwingclone.entity;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OrderItem {
    private Long id;
    private Long orderId;
    private Long courseId;
    private String courseTitle;
    private BigDecimal price;
}
