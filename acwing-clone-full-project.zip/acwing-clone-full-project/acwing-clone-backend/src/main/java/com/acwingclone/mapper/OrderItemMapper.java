package com.acwingclone.mapper;

import com.acwingclone.entity.OrderItem;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface OrderItemMapper {

    @Insert("INSERT INTO order_item(order_id, course_id, course_title, price) " +
            "VALUES (#{orderId}, #{courseId}, #{courseTitle}, #{price})")
    void save(OrderItem item);
}
