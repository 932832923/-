package com.acwingclone.entity;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class Order {
    private Long id;
    private Long userId;
    private BigDecimal totalPrice;
    private String status; // PENDING / PAID / CANCELLED
    private Date createTime;
}
