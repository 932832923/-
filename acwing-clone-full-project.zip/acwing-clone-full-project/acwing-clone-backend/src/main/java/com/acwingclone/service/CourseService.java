package com.acwingclone.service;

import com.acwingclone.entity.Course;

import java.util.List;

public interface CourseService {
    List<Course> getAllCourses();
    Course getCourseDetail(Long id);
}
