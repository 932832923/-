package com.acwingclone.controller;

import com.acwingclone.dto.OrderRequest;
import com.acwingclone.entity.Order;
import com.acwingclone.service.OrderService;
import com.acwingclone.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/api/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/create")
    public String createOrder(@RequestBody OrderRequest request, HttpServletRequest httpReq) {
        String token = httpReq.getHeader("Authorization").replace("Bearer ", "");
        String username = JwtUtil.getUsername(token);
        Long userId = getUserIdByUsername(username); // 此处应实现真实用户查找
        orderService.createOrder(userId, request);
        return "订单创建成功";
    }

    @GetMapping("/my")
    public List<Order> myOrders(HttpServletRequest httpReq) {
        String token = httpReq.getHeader("Authorization").replace("Bearer ", "");
        String username = JwtUtil.getUsername(token);
        Long userId = getUserIdByUsername(username); // 同样应由数据库查找
        return orderService.getUserOrders(userId);
    }

    // 🧪 临时方法：模拟用户查找
    private Long getUserIdByUsername(String username) {
        if (username.equals("admin")) return 1L;
        return 2L; // 真实项目应查数据库
    }
}
