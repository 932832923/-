package com.acwingclone.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class OrderRequest {
    private BigDecimal totalPrice;
    private List<Long> courseIdList;
}
