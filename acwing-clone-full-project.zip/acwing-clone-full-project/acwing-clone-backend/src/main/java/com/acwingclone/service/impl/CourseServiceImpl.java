package com.acwingclone.service.impl;

import com.acwingclone.entity.Course;
import com.acwingclone.mapper.CourseMapper;
import com.acwingclone.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseMapper courseMapper;

    @Override
    public List<Course> getAllCourses() {
        return courseMapper.getAllActiveCourses();
    }

    @Override
    public Course getCourseDetail(Long id) {
        return courseMapper.getCourseById(id);
    }
}
