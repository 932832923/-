package com.acwingclone.controller;

import com.acwingclone.entity.User;
import com.acwingclone.service.UserService;
import com.acwingclone.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public String register(@RequestBody User user) {
        userService.register(user);
        return "注册成功";
    }

    @PostMapping("/login")
    public String login(@RequestBody User user) {
        String token = userService.login(user.getUsername(), user.getPassword());
        return token != null ? token : "用户名或密码错误";
    }

    @GetMapping("/me")
    public User getCurrentUser(HttpServletRequest request) {
        String token = request.getHeader("Authorization").replace("Bearer ", "");
        String username = JwtUtil.getUsername(token);
        return userService.getUserByUsername(username);
    }
}
