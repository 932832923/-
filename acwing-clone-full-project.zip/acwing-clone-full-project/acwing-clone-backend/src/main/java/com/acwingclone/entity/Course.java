package com.acwingclone.entity;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class Course {
    private Long id;
    private String title;
    private String description;
    private BigDecimal price;
    private String imageUrl;
    private Boolean isMemberOnly;
    private Integer videoCount;
    private String status; // ACTIVE / INACTIVE
    private Date createTime;
}
