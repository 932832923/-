package com.acwingclone.mapper;

import com.acwingclone.entity.Order;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface OrderMapper {

    @Insert("INSERT INTO `order` (user_id, total_price, status, create_time) " +
            "VALUES (#{userId}, #{totalPrice}, #{status}, NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void save(Order order);

    @Select("SELECT * FROM `order` WHERE user_id = #{userId}")
    List<Order> findOrdersByUserId(Long userId);
}
