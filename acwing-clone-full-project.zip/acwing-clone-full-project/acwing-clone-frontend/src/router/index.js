import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Login from '../views/Login.vue'
import Register from '../views/Register.vue'

const routes = [
    { path: '/', component: Home },
    { path: '/login', component: Login },
    { path: '/register', component: Register },
    { path: '/courses', component: () => import('../views/CourseList.vue') },
    { path: '/course/:id', component: () => import('../views/CourseDetail.vue') },
    { path: '/cart', component: () => import('../views/Cart.vue') },
    { path: '/checkout', component: () => import('../views/Checkout.vue') },
    { path: '/orders', component: () => import('../views/MyOrders.vue') },
    { path: '/profile', component: () => import('../views/Profile.vue') }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router
