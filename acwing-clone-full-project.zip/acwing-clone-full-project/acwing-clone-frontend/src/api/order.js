import request from './axios'

export function createOrder(data) {
    return request.post('/order/create', data)
}

export function getMyOrders() {
    return request.get('/order/my')
}
