import request from './axios'

export function getCourseList() {
    return request.get('/course/list')
}

export function getCourseDetail(id) {
    return request.get(`/course/${id}`)
}
