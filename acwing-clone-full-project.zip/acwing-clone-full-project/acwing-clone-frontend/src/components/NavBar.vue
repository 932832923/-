<template>
    <el-menu mode="horizontal" router :default-active="$route.path" class="nav-bar" background-color="#ffffff">
        <el-menu-item index="/">首页</el-menu-item>
        <el-menu-item index="/courses">课程</el-menu-item>
        <el-menu-item index="/cart">购物车</el-menu-item>

        <div class="nav-right">
            <el-sub-menu v-if="userStore.token" index="user">
                <template #title>
                    <span>{{ userStore.userInfo?.nickname || '用户' }}</span>
                </template>
                <el-menu-item index="/profile">我的资料</el-menu-item>
                <el-menu-item index="/orders">我的订单</el-menu-item>
                <el-menu-item @click="logout">退出登录</el-menu-item>
            </el-sub-menu>

            <template v-else>
                <el-menu-item index="/login">登录</el-menu-item>
                <el-menu-item index="/register">注册</el-menu-item>
            </template>
        </div>
    </el-menu>
</template>

<script setup>
    import { useUserStore } from '@/store/user'
    import { getUserInfo } from '@/api/user'
    import { onMounted } from 'vue'

    const userStore = useUserStore()

    const logout = () => {
        userStore.logout()
        location.reload()
    }

    onMounted(async () => {
        if (userStore.token && !userStore.userInfo) {
            const res = await getUserInfo()
            userStore.userInfo = res.data
        }
    })
</script>

<style scoped>
    .nav-bar {
        line-height: 60px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    }

    .nav-right {
        margin-left: auto;
        display: flex;
        align-items: center;
    }
</style>
