<template>
    <div id="app">
        <NavBar />
        <el-container class="main-container">
            <router-view />
        </el-container>
    </div>
</template>

<script setup>
    import NavBar from '@/components/NavBar.vue'
</script>

<style>
    body {
        margin: 0;
        font-family: 'Segoe UI', 'Helvetica Neue', sans-serif;
        background-color: #f8f8f8;
    }

    #app {
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    .main-container {
        padding: 20px;
    }
</style>
