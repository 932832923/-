<template>
    <div class="course-detail" v-if="course">
        <el-card>
            <h2>{{ course.title }}</h2>
            <img :src="course.imageUrl || defaultImg" class="banner" />
            <p class="desc">{{ course.description }}</p>
            <p>
                <b>价格：</b>
                <span v-if="!course.isMemberOnly">￥{{ course.price }}</span>
                <span v-else>会员专享</span>
            </p>
            <el-button type="primary" @click="addToCart">加入购物车</el-button>
        </el-card>
    </div>
</template>

<script setup>
    import { ref, onMounted } from 'vue'
    import { useRoute } from 'vue-router'
    import { getCourseDetail } from '@/api/course'
    import { ElMessage } from 'element-plus'

    const course = ref(null)
    const route = useRoute()
    const defaultImg = 'https://via.placeholder.com/600x300?text=Course+Detail'

    const addToCart = () => {
        let cart = JSON.parse(localStorage.getItem('cart') || '[]')
        if (!cart.includes(course.value.id)) {
            cart.push(course.value.id)
            localStorage.setItem('cart', JSON.stringify(cart))
            ElMessage.success('已加入购物车')
        } else {
            ElMessage.warning('已在购物车中')
        }
    }

    onMounted(async () => {
        const res = await getCourseDetail(route.params.id)
        course.value = res.data
    })
</script>

<style scoped>
    .banner {
        width: 100%;
        height: 300px;
        object-fit: cover;
        margin-bottom: 20px;
    }
    .desc {
        margin: 15px 0;
    }
</style>
