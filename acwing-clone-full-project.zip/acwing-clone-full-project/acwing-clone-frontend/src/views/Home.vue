
<template>
    <div class="home">
        <el-carousel :interval="5000" arrow="always">
            <el-carousel-item v-for="item in banners" :key="item">
                <img :src="item" class="banner-img" />
            </el-carousel-item>
        </el-carousel>
        <h2>   </h2>
        <div class="course-list">
            <CourseCard v-for="course in courses" :key="course.id" :course="course" @click="goDetail(course.id)" />
        </div>
    </div>
</template>

<script setup>
    import { ref, onMounted } from 'vue'
    import { getCourseList } from '@/api/course'
    import CourseCard from '@/components/CourseCard.vue'
    import { useRouter } from 'vue-router'

    const banners = [
        'https://via.placeholder.com/960x300?text=Banner+1',
        'https://via.placeholder.com/960x300?text=Banner+2'
    ]
    const courses = ref([])
    const router = useRouter()

    onMounted(async () => {
        const res = await getCourseList()
        courses.value = res.data.slice(0, 4)
    })

    const goDetail = (id) => {
        router.push(`/course/${id}`)
    }
</script>

<style scoped>
    .banner-img {
        width: 100%;
        height: 300px;
        object-fit: cover;
    }
    .course-list {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        margin-top: 20px;
    }
</style>
