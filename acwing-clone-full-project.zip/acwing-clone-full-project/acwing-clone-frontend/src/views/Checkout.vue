<template>
    <div class="checkout">
        <h2>确认订单</h2>
        <el-card>
            <div v-for="course in courses" :key="course.id" class="line">
                {{ course.title }} —— ￥{{ course.price }}
            </div>
            <div class="total">总计：￥{{ totalPrice }}</div>
            <el-button type="primary" @click="submitOrder">提交订单</el-button>
        </el-card>
    </div>
</template>

<script setup>
    import { ref, computed, onMounted } from 'vue'
    import { useCartStore } from '@/store/cart'
    import { getCourseDetail } from '@/api/course'
    import { createOrder } from '@/api/order'
    import { ElMessage } from 'element-plus'
    import { useRouter } from 'vue-router'

    const cartStore = useCartStore()
    const courses = ref([])
    const router = useRouter()

    onMounted(async () => {
        courses.value = []
        for (const id of cartStore.cart) {
            const res = await getCourseDetail(id)
            courses.value.push(res.data)
        }
    })

    const totalPrice = computed(() =>
        courses.value.reduce((sum, item) => sum + parseFloat(item.price), 0)
    )

    const submitOrder = async () => {
        const courseIds = courses.value.map(c => c.id)
        const res = await createOrder({
            totalPrice: totalPrice.value,
            courseIdList: courseIds
        })
        if (res.data === '订单创建成功') {
            ElMessage.success('下单成功')
            cartStore.clear()
            router.push('/orders')
        }
    }
</script>

<style scoped>
    .checkout {
        padding: 20px;
    }
    .line {
        margin: 10px 0;
    }
    .total {
        margin-top: 15px;
        font-weight: bold;
    }
</style>
