
<template>
    <div class="profile">
        <h2>个人资料</h2>
        <el-descriptions :column="1" border>
            <el-descriptions-item label="用户名">{{ userInfo.username }}</el-descriptions-item>
            <el-descriptions-item label="昵称">{{ userInfo.nickname || '-' }}</el-descriptions-item>
            <el-descriptions-item label="邮箱">{{ userInfo.email || '-' }}</el-descriptions-item>
            <el-descriptions-item label="角色">{{ userInfo.role }}</el-descriptions-item>
        </el-descriptions>
    </div>
</template>

<script setup>
    import { ref, onMounted } from 'vue'
    import { getUserInfo } from '@/api/user'
    import { useUserStore } from '@/store/user'

    const userInfo = ref({})
    const userStore = useUserStore()

    onMounted(async () => {
        if (userStore.userInfo) {
            userInfo.value = userStore.userInfo
        } else {
            const res = await getUserInfo()
            userStore.userInfo = res.data
            userInfo.value = res.data
        }
    })
</script>

<style scoped>
    .profile {
        padding: 20px;
    }
</style>
