<template>
    <div class="login-container">
        <el-card class="box-card">
            <h2>登录</h2>
            <el-form @submit.prevent="handleLogin">
                <el-form-item label="用户名">
                    <el-input v-model="form.username" autocomplete="off" />
                </el-form-item>
                <el-form-item label="密码">
                    <el-input v-model="form.password" type="password" autocomplete="off" />
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="handleLogin">登录</el-button>
                    <el-button type="text" @click="goRegister">没有账号？注册</el-button>
                </el-form-item>
            </el-form>
        </el-card>
    </div>
</template>

<script setup>
    import { ref } from 'vue'
    import { useRouter } from 'vue-router'
    import { login } from '@/api/user'
    import { ElMessage } from 'element-plus'
    import { useUserStore } from '@/store/user'

    const router = useRouter()
    const userStore = useUserStore()

    const form = ref({
        username: '',
        password: ''
    })

    const handleLogin = async () => {
        const res = await login(form.value)
        if (res.data.startsWith('ey')) {
            userStore.setToken(res.data)
            ElMessage.success('登录成功')
            router.push('/')
        } else {
            ElMessage.error('用户名或密码错误')
        }
    }

    const goRegister = () => {
        router.push('/register')
    }
</script>

<style scoped>
    .login-container {
        max-width: 400px;
        margin: 100px auto;
    }
</style>
