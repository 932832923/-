<template>
    <div class="container">
        <h2>课程列表</h2>
        <div class="grid">
            <CourseCard
                    v-for="item in courses"
                    :key="item.id"
                    :course="item"
                    @click="goToDetail(item.id)"
            />
        </div>
    </div>
</template>

<script setup>
    import { ref, onMounted } from 'vue'
    import { getCourseList } from '@/api/course'
    import CourseCard from '@/components/CourseCard.vue'
    import { useRouter } from 'vue-router'

    const router = useRouter()
    const courses = ref([])

    const goToDetail = (id) => {
        router.push(`/course/${id}`)
    }

    onMounted(async () => {
        const res = await getCourseList()
        courses.value = res.data
    })
</script>

<style scoped>
    .container {
        padding: 20px;
    }
    .grid {
        display: flex;
        flex-wrap: wrap;
    }
</style>
