
<template>
    <div class="my-orders">
        <h2>我的订单</h2>
        <el-table :data="orders" style="width: 100%">
            <el-table-column prop="id" label="订单号" width="120" />
            <el-table-column prop="totalPrice" label="总价" />
            <el-table-column prop="status" label="状态" />
            <el-table-column prop="createTime" label="创建时间" />
        </el-table>
    </div>
</template>

<script setup>
    import { onMounted, ref } from 'vue'
    import { getMyOrders } from '@/api/order'

    const orders = ref([])

    onMounted(async () => {
        const res = await getMyOrders()
        orders.value = res.data
    })
</script>

<style scoped>
    .my-orders {
        padding: 20px;
    }
</style>
