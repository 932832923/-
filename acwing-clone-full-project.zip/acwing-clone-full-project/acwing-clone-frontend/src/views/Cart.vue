<template>
    <div class="cart-container">
        <h2>我的购物车</h2>
        <el-table :data="selectedCourses" border>
            <el-table-column prop="title" label="课程名称" />
            <el-table-column prop="price" label="价格" />
            <el-table-column label="操作">
                <template #default="scope">
                    <el-button type="danger" size="small" @click="remove(scope.row.id)">移除</el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="footer">
            <div>总价：￥{{ totalPrice }}</div>
            <el-button type="primary" @click="checkout" :disabled="selectedCourses.length === 0">去结算</el-button>
        </div>
    </div>
</template>

<script setup>
    import { onMounted, ref, computed } from 'vue'
    import { getCourseDetail } from '@/api/course'
    import { useCartStore } from '@/store/cart'
    import { useRouter } from 'vue-router'

    const cartStore = useCartStore()
    const selectedCourses = ref([])
    const router = useRouter()

    const remove = (id) => {
        cartStore.remove(id)
        selectedCourses.value = selectedCourses.value.filter(item => item.id !== id)
    }

    const totalPrice = computed(() =>
        selectedCourses.value.reduce((sum, item) => sum + parseFloat(item.price), 0)
    )

    onMounted(async () => {
        selectedCourses.value = []
        for (const id of cartStore.cart) {
            const res = await getCourseDetail(id)
            selectedCourses.value.push(res.data)
        }
    })

    const checkout = () => {
        router.push('/checkout')
    }
</script>

<style scoped>
    .cart-container {
        padding: 20px;
    }
    .footer {
        margin-top: 20px;
        display: flex;
        justify-content: space-between;
    }
</style>
