<template>
    <div class="register-container">
        <el-card>
            <h2>注册</h2>
            <el-form @submit.prevent="handleRegister">
                <el-form-item label="用户名">
                    <el-input v-model="form.username" />
                </el-form-item>
                <el-form-item label="密码">
                    <el-input type="password" v-model="form.password" />
                </el-form-item>
                <el-form-item label="邮箱">
                    <el-input v-model="form.email" />
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="handleRegister">注册</el-button>
                    <el-button type="text" @click="goLogin">已有账号？去登录</el-button>
                </el-form-item>
            </el-form>
        </el-card>
    </div>
</template>

<script setup>
    import { ref } from 'vue'
    import { useRouter } from 'vue-router'
    import { register } from '@/api/user'
    import { ElMessage } from 'element-plus'

    const router = useRouter()

    const form = ref({
        username: '',
        password: '',
        email: ''
    })

    const handleRegister = async () => {
        const res = await register(form.value)
        ElMessage.success(res.data)
        router.push('/login')
    }

    const goLogin = () => {
        router.push('/login')
    }
</script>

<style scoped>
    .register-container {
        max-width: 400px;
        margin: 100px auto;
    }
</style>
