<template>
    <el-menu mode="horizontal" :router="true">
        <el-menu-item index="/">首页</el-menu-item>
        <el-menu-item index="/courses">课程</el-menu-item>
        <el-menu-item index="/cart">购物车</el-menu-item>
        <div style="flex:1"></div>
        <el-sub-menu v-if="userStore.token" index="user">
            <template #title>{{ userStore.userInfo?.nickname || '用户' }}</template>
            <el-menu-item index="/profile">我的资料</el-menu-item>
            <el-menu-item @click="logout">退出登录</el-menu-item>
        </el-sub-menu>
        <el-menu-item v-else index="/login">登录</el-menu-item>
    </el-menu>
</template>

<script setup>
    import { useUserStore } from '@/store/user'
    import { onMounted } from 'vue'
    import { getUserInfo } from '@/api/user'

    const userStore = useUserStore()

    const logout = () => {
        userStore.logout()
        location.reload()
    }

    onMounted(async () => {
        if (userStore.token && !userStore.userInfo) {
            const res = await getUserInfo()
            userStore.userInfo = res.data
        }
    })
</script>
