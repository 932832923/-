import { defineStore } from 'pinia'

export const useCartStore = defineStore('cart', {
    state: () => ({
        cart: JSON.parse(localStorage.getItem('cart') || '[]')
    }),
    actions: {
        add(id) {
            if (!this.cart.includes(id)) {
                this.cart.push(id)
                this.save()
            }
        },
        remove(id) {
            this.cart = this.cart.filter(item => item !== id)
            this.save()
        },
        clear() {
            this.cart = []
            this.save()
        },
        save() {
            localStorage.setItem('cart', JSON.stringify(this.cart))
        }
    }
})
